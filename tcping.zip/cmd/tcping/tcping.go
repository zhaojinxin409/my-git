package main

import (
	"fmt"
	"github.com/sh3rp/tcping"
	"os"
	"time"
)

var VERSION = "1.3.1"

var host string
var port int
var iface string
var timeout int64
var debug bool
var count int
var showVersion bool

func main() {
	host := "10.200.17.45"
	port := 10001
	iface = "WLAN"

	if showVersion {
		fmt.Printf("tcping v%s\n", VERSION)
		return
	}

	if host == "" {
		fmt.Printf("Must supply a host to ping.\n")
		os.Exit(1)
	}

	src := tcping.GetInterface(iface)

	probe := tcping.NewProbe(src, timeout, debug)

	if debug {
		fmt.Printf("Src IP: %s\n\n", src)
	}

	if count > 0 {
		for i := 0; i < count; i++ {
			sendProbe(probe, host, uint16(port))
			time.Sleep(1 * time.Second)
		}
	} else {
		for {
			sendProbe(probe, host, uint16(port))
			time.Sleep(1 * time.Second)
		}
	}
}

func sendProbe(probe tcping.Probe, dstIp string, dstPort uint16) {
	result, err := probe.GetLatency(dstIp, dstPort)
	if err != nil {
		fmt.Printf("Error: %v\n", err)
		return
	}
	fmt.Println(result)
}
